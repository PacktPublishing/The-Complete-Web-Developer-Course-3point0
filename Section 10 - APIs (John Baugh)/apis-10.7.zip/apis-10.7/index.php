<?php
    require "vendor/autoload.php";
    use Abraham\TwitterOAuth\TwitterOAuth;

    define('CONSUMER_KEY', '1KURoThj0XMThUYDVMAoAt4DD');
    define('CONSUMER_SECRET', 'xa8xqN2fRZKmuLTWrnuWMJQnhjq0BIsaj3we52q3kFHGQW6Bsu');

    $access_token = '1243069950933303296-hshhKzWwUB1Toci7vBgECoscxgNe67';
    $access_token_secret = 'NDfB3OGO7j1NB1OM15I36rafnjTg3xpoxCiLbQjzvFhYK';

     $connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, 
                                   $access_token, $access_token_secret);

     $content = $connection->get("account/verify_credentials");

     $statuses = $connection->post("statuses/update", ["status" => "This came from my Twitter API test!"]);

     $statuses = $connection->get("statuses/home_timeline", ["count" => 5, "exclude_replies" => true]);

     print_r($statuses);
?>