<?php
    echo "I'm an included file!";
?>