<?php 
    echo "<strong>Hello world!</strong>"; 
?>