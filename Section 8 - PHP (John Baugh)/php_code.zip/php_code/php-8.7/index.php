<?php
    $family = array("Jack", "Ellen", "Jackson", "John");

    foreach($family as $key => $value) {
        $family[$key] = $value . " Baugh";
        echo "Array item " . $key . " is " . $value . "<br>";
        echo "Update: $family[$key]<br>";
    }//end foreach

    echo "<br><br>";
    echo "Regular for loop:<br><br>";
    for($i = 0; $i < sizeof($family); $i++) {
        echo $family[$i] . "<br>";
    }

    echo "<br><br>";

    for($i = 10; $i >= 0; $i--) {
        echo $i . "<br>";
    }//end for
?>